"""按节点编译质量先验、实际路线费用与可选规模匹配时延观测。"""
from .node_routing import NodeProfile, number, validate_profiles
from .routing_actions import action_binding
from .task_plan import validate_plan
from .latency_forecast import validate_latency_evidence, forecast_latency
from .node_quality_scope import validate_scope, matches_scope, scope_receipt


def prediction(raw, output_cap):
    if not isinstance(raw, dict) or set(raw) - {'quality', 'latencyMs', 'outputTokens'}:
        raise ValueError('invalid routing prediction fields')
    output = raw.get('outputTokens')
    if output is not None and (type(output) is not int or not 1 <= output <= output_cap):
        raise ValueError('routing outputTokens must fit model maxOutputTokens')
    return {'quality': number(raw.get('quality'), 'configured quality', maximum=100),
            'latency_ms': number(raw.get('latencyMs'), 'configured latency', positive=True),
            'output_tokens': output}


def compile_routing(raw, output_cap):
    if not isinstance(raw, dict) or set(raw) - {'quality', 'latencyMs', 'outputTokens', 'profiles', 'latencyEvidence'}:
        raise ValueError('invalid routing prediction fields')
    default = prediction({k: v for k, v in raw.items() if k not in {'profiles', 'latencyEvidence'}}, output_cap)
    overrides = raw.get('profiles', [])
    if not isinstance(overrides, list) or len(overrides) > 128:
        raise ValueError('routing profiles must be an array of at most 128 strata')
    profiles = []
    for item in overrides:
        selectors = {'nodeType', 'difficulty', 'risk', 'inputMinTokens', 'inputMaxTokens'}
        if not isinstance(item, dict) or set(item) - selectors - {'quality', 'latencyMs', 'outputTokens', 'evidence'}:
            raise ValueError('invalid routing profile fields')
        values = prediction({k: v for k, v in item.items() if k not in selectors | {'evidence'}}, output_cap)
        selector = NodeProfile('configured', item.get('nodeType'), values['quality'], 0,
            values['latency_ms'], 0, difficulty=item.get('difficulty'), risk=item.get('risk'),
            input_min_tokens=item.get('inputMinTokens', 256), input_max_tokens=item.get('inputMaxTokens', 131073))
        evidence = item.get('evidence')
        if evidence is not None:
            if (not isinstance(evidence, dict) or evidence.get('kind') != 'independent-node-evaluation'
                    or type(evidence.get('samples')) is not int or evidence['samples'] < 0
                    or any(not isinstance(evidence.get(k), str) or len(evidence[k]) != 64
                           for k in ('bundleSha256', 'observationSha256'))):
                raise ValueError('invalid node quality evidence')
            values['evidence'] = dict(evidence)
            if 'taskScope' in evidence:
                values['evidence']['taskScope'] = validate_scope(evidence['taskScope'])
        profiles.append((selector, values))
    validate_profiles(tuple(p for p, _ in profiles))
    return {**default, 'profiles': profiles, 'latency_evidence':
            validate_latency_evidence(raw['latencyEvidence']) if 'latencyEvidence' in raw else None}


def configured_profile(configuration, manifest, plan, *, input_forecasts=None,
                       cost_input_forecasts=None, task=None):
    plan = validate_plan(plan)
    stratified = bool(plan.contracts)
    rows, basis = {}, {}
    for model in manifest.candidates:
        default = configuration.predictions[model.model_id]
        if default['profiles'] and not stratified:
            raise ValueError('routing profiles require a v2 DAG with node capability contracts')
        # Clipping an effort's expected token use would reuse its quality/latency
        # forecast for a different execution envelope. Reject instead of guessing.
        for forecast in [default, *(v for _, v in default['profiles'])]:
            if forecast['output_tokens'] is not None and forecast['output_tokens'] > model.max_output_tokens:
                raise ValueError(f'{model.model_id}: routing outputTokens exceeds effective maxOutputTokens; raise the application output cap or update predictions')
        for node in plan.nodes:
            matches = [(index, value) for index, (selector, value) in enumerate(default['profiles'])
                if selector.matches(node, plan)
                and matches_scope((value.get('evidence') or {}).get('taskScope'), task)]
            index, forecast = matches[0] if matches else (None, default)
            capability = plan.contracts.get(node.node_id, {}).get('capability', {})
            scoped = [(value.get('evidence') or {}).get('taskScope') for selector, value in default['profiles']
                if selector.node_type == node.node_type
                and selector.difficulty == capability.get('difficulty') and selector.risk == capability.get('risk')
                and (value.get('evidence') or {}).get('taskScope')]
            scope = (forecast.get('evidence') or {}).get('taskScope') or (scoped[0] if scoped else None)
            outside_scope = bool(scoped and not any(matches_scope(s, task) for s in scoped))
            failure_guard = False
            if not matches and capability:
                # 容量边界变化不能抹去同类节点的已知失败。新分层有独立正面证据时，
                # 上面的精确匹配仍可采用它；否则需要重新验证，不能回到乐观全局先验。
                for selector, values in default['profiles']:
                    evidence = values.get('evidence') or {}
                    if (evidence.get('kind') == 'independent-node-evaluation'
                            and matches_scope(evidence.get('taskScope'), task)
                            and evidence.get('excludedReason') in {
                                'semantic-criterion-failure', 'known-contract-rejection',
                                'held-out-semantic-criterion-failure', 'held-out-known-contract-rejection'}
                            and selector.node_type == node.node_type
                            and selector.difficulty == capability['difficulty']
                            and selector.risk == capability['risk']):
                        forecast = {**values, 'quality': 0, 'output_tokens': None}
                        failure_guard = True
                        break
            input_cap = capability.get('input_budget_tokens', 131072)
            input_forecast = input_cap if input_forecasts is None else input_forecasts[node.node_id]
            number(input_forecast, 'forecast input', maximum=input_cap, positive=True)
            cost_input = (input_forecast if cost_input_forecasts is None else
                          cost_input_forecasts[node.node_id])
            number(cost_input, 'routing cost input forecast', positive=True)
            if cost_input > input_forecast:
                raise ValueError('routing cost input forecast exceeds conservative input bound')
            if forecast['output_tokens'] is not None:
                output = forecast['output_tokens']
                if forecast.get('evidence') and capability:
                    output = max(output, min(model.max_output_tokens, capability['expected_output_tokens']))
            elif cost_input_forecasts is not None and capability:
                output = min(model.max_output_tokens, capability['expected_output_tokens'])
            else:
                output = model.max_output_tokens
            selector = ({'difficulty': capability['difficulty'], 'risk': capability['risk'],
                'input_min_tokens': input_cap, 'input_max_tokens': input_cap + 1} if stratified else {})
            latency = (forecast_latency(default['latency_evidence'], cost_input, output, forecast['latency_ms'])
                       if default.get('latency_evidence') is not None else None)
            row = {'model_id': model.model_id, 'node_type': node.node_type, 'samples': 0,
                'quality': forecast['quality'], 'latency_ms': latency['prediction_ms'] if latency else forecast['latency_ms'],
                'cost': cost_input / 1000 * model.input_cost_per_1k + output / 1000 * model.output_cost_per_1k,
                **selector}
            key = (model.model_id, node.node_type, *selector.values())
            # 相同画像区间可能覆盖不同父输出预测；共享行取较大费用，避免遍历顺序低估。
            if key not in rows:
                rows[key] = row
            else:
                rows[key]['cost'] = max(rows[key]['cost'], row['cost'])
                rows[key]['latency_ms'] = max(rows[key]['latency_ms'], row['latency_ms'])
            basis.setdefault(node.node_id, {})[model.model_id] = {'input_tokens': cost_input,
                'output_tokens': output, 'source': 'default' if index is None else f'profiles[{index}]',
                'quality_source': ('known-node-failure-outside-observed-input-range' if failure_guard else
                    'global-prior-outside-node-evidence-task-scope' if index is None and outside_scope else
                    'global-prior-no-matching-node-evidence' if index is None else
                    'independent-node-evaluation' if forecast.get('evidence') else 'configured-node-prior'),
                'quality_evidence': forecast.get('evidence'),
                'evidence_scope': scope_receipt(scope, task),
                'quality_prior': forecast['quality'],
                'node_features': {'type': node.node_type, 'difficulty': capability.get('difficulty'),
                    'risk': capability.get('risk'), 'input_capacity': input_cap}}
            if latency is not None:
                basis[node.node_id][model.model_id]['latency'] = latency
            if input_forecasts is not None:
                basis[node.node_id][model.model_id].update(input_capacity=input_cap,
                    input_forecast_source=('observed-byte-ratio-v1' if cost_input_forecasts is not None
                                           else 'serialized-input-and-planned-parent-output'))
            if cost_input_forecasts is not None:
                basis[node.node_id][model.model_id].update(
                    conservative_input_bound=input_forecast,
                    conservative_input_source='serialized-input-and-planned-parent-output',
                    cost_forecast_source='observed-byte-ratio-v1',
                    output_forecast_source=('independent-node-usage-and-planned-output' if forecast.get('evidence')
                        and forecast['output_tokens'] is not None else 'explicit-routing-profile'
                        if forecast['output_tokens'] is not None else 'planned-node-output'))
    empirical = any(row.get('quality_evidence') for node in basis.values() for row in node.values())
    return {'schema_version': 'node-routing-profile-v2' if stratified else 'node-routing-profile-v1',
        'kind': 'configured', 'billing_unit': manifest.billing_unit,
        'scope': ('质量含范围内独立节点实测与未覆盖的配置先验；逐候选依据见 forecast_basis。'
                  if empirical else '质量为配置先验；没有匹配本任务的独立节点实测。')
                 + '时延可使用同规模调用观测，不代表任务成功率或 SLA。',
        'provenance': '本次 provider-config.json；时延观测与匹配数量见 forecast_basis，未新增探测调用。',
        'candidates': list(rows.values()), 'forecast_basis': basis,
        'model_bindings': {m.model_id: m.api_model for m in manifest.candidates},
        'action_bindings': {m.model_id: action_binding(m) for m in manifest.candidates}}


def selected_quality_basis(profile, assignments):
    """概括实际选中的分层来源；不将未匹配的实测外推为任务质量证明。"""
    basis = (profile or {}).get('forecast_basis', {})
    rows = [basis.get(nid, {}).get(mid, {}) for nid, mid in (assignments or {}).items()]
    empirical = [row.get('quality_source') == 'independent-node-evaluation' for row in rows]
    if empirical and all(empirical):
        return 'independent-node-evaluation'
    if any(empirical):
        return 'independent-node-evaluation-and-configured-prior'
    return 'configured-profile-prior'
