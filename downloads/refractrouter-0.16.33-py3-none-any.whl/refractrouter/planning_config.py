"""规划路由配置：独立角色绑定、零调用预检与宿主无关合同。"""
from copy import deepcopy
from dataclasses import dataclass
from datetime import date
import json
import math
from pathlib import Path

from .schemas import ModelSpec
from .application_config import compile_privacy, SCHEMA_V2 as PRIVACY_SCHEMA_V2
from .dsh_model_pool import frozen_usd_cny_rate

SCHEMA = "refractagent-planning-v1"
SCHEMA_V2 = "refractagent-planning-v2"
SCHEMA_V3 = "refractagent-planning-v3"
SCHEMA_V4 = "refractagent-planning-v4"
SCHEMA_V5 = "refractagent-planning-v5"
SCHEMA_V6 = "refractagent-planning-v6"
SCHEMA_V7 = "refractagent-planning-v7"
PROTOCOL = "refractagent-planning/4"
MAX_CONFIG_BYTES = 16 * 1024 * 1024
STRATEGIES = ("stage", "task", "composite", "advisor", "escalation", "static")
NAMES = dict(zip(STRATEGIES, ("阶段", "任务", "组合", "审核", "升级", "静态")))
REQUIRED = {
    "static": ("efficient",), "stage": ("efficient", "capable"),
    "task": (),
    "composite": ("efficient", "capable", "classifier"),
    "advisor": ("efficient", "advisor"),
    "escalation": (),
}
DEFAULTS = {"window": 3, "threshold": .5, "holdTurns": 2, "baseThreshold": .5,
            "thresholdStep": .1, "maxReviews": 1, "maxRedos": 1, "stallTurns": 0,
            "confirmations": 2, "staticMode": "fixed", "seed": 0,
            "efficientWeight": 1, "capableWeight": 1}

TASK_CAPABILITY_LEVELS = ("unknown", "declared", "connected", "verified")
TASK_MODALITIES = ("imageInput", "videoInput", "imageOutput", "videoOutput")


def number(value, name, minimum=0, maximum=float("inf"), integer=False):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError(f"{name} 数值不合法")
    if integer and type(value) is not int:
        raise ValueError(f"{name} 必须是整数")
    return value


def obj(value, allowed, name):
    if not isinstance(value, dict) or set(value) - set(allowed):
        raise ValueError(f"{name} 字段不合法")
    return value


@dataclass(frozen=True)
class PlanningModel(ModelSpec):
    billing_mode: str = "metered"
    deployment: str = "external-cloud"
    trust_policy: str | None = None
    cache_write_cost_per_1k: float | None = None
    source_billing_unit: str | None = None
    conversion_rate: float | None = None
    conversion_source: str | None = None
    conversion_as_of: str | None = None
    capabilities: dict | None = None
    capability_card: str = ""
    reference_pricing: dict | None = None


def _capabilities(raw):
    value = obj(raw or {}, ("mainExecutor", "toolCalling", "modalities", "formats", "limits",
                            "source", "checkedAt"), "model.capabilities")
    main = value.get("mainExecutor", True)
    if type(main) is not bool:
        raise ValueError("capabilities.mainExecutor 必须是布尔值")
    tools = value.get("toolCalling", "unknown")
    if tools not in TASK_CAPABILITY_LEVELS:
        raise ValueError("capabilities.toolCalling 状态无效")
    modalities = obj(value.get("modalities", {}), TASK_MODALITIES, "capabilities.modalities")
    for name, level in modalities.items():
        if level not in TASK_CAPABILITY_LEVELS:
            raise ValueError(f"capabilities.{name} 状态无效")
    formats = obj(value.get("formats", {}), TASK_MODALITIES, "capabilities.formats")
    for name, entries in formats.items():
        if (not isinstance(entries, list) or len(entries) > 32
                or any(not isinstance(item, str) or not item or len(item) > 100 for item in entries)):
            raise ValueError(f"capabilities.formats.{name} 无效")
    limits = obj(value.get("limits", {}), ("maxImages", "maxImageBytes", "maxVideoBytes",
        "maxVideoSeconds", "maxWidth", "maxHeight"), "capabilities.limits")
    for name, amount in limits.items():
        number(amount, f"capabilities.limits.{name}", 0, 10**12)
    for name in ("source", "checkedAt"):
        if value.get(name) is not None and (not isinstance(value[name], str) or len(value[name]) > 1000):
            raise ValueError(f"capabilities.{name} 无效")
    return {"mainExecutor": main, "toolCalling": tools,
        "modalities": {name: modalities.get(name, "unknown") for name in TASK_MODALITIES},
        "formats": formats, "limits": limits,
        **({"source": value["source"]} if value.get("source") else {}),
        **({"checkedAt": value["checkedAt"]} if value.get("checkedAt") else {})}


def _task_config(raw, schema, declared_ids, roles):
    supplied = raw.get("task")
    if supplied is None:
        pool = [model for model in (roles.get("efficient"), roles.get("capable")) if model]
        return {"mode": "legacy", "pool": list(dict.fromkeys(pool)),
            "fallback": roles.get("capable"), "judge": {"type": "llm", "modelId": roles.get("classifier")},
            "threshold": .8, "maxInputChars": 12000}
    if schema not in (SCHEMA_V3, SCHEMA_V4, SCHEMA_V5, SCHEMA_V6, SCHEMA_V7):
        raise ValueError(f"Task 模型池需要 {SCHEMA_V3} 或 {SCHEMA_V4}")
    task = obj(supplied, ("pool", "fallback", "judge", "threshold", "maxInputChars",
                          "maxExecutionOutputTokens", "maxJudgeOutputTokens"), "task")
    pool = task.get("pool")
    if (not isinstance(pool, list) or not pool or len(pool) > 64 or len(set(pool)) != len(pool)
            or any(not isinstance(model, str) or model not in declared_ids for model in pool)):
        raise ValueError("task.pool 必须引用不重复的已配置模型")
    fallback = task.get("fallback")
    if fallback not in pool:
        raise ValueError("task.fallback 必须属于模型池")
    judge = obj(task.get("judge", {}), ("type", "modelId", "adapter", "modelPath", "sourceModel",
        "revision", "device", "dtype", "method"), "task.judge")
    judge_type = judge.get("type")
    if judge_type not in ("llm", "local-decision", "jev"):
        raise ValueError("task.judge.type 必须是 llm、local-decision 或 jev")
    if judge_type == "llm":
        if judge.get("modelId") not in declared_ids:
            raise ValueError("轻量 LLM Judge 必须引用已配置模型")
    elif judge_type == "local-decision":
        from .local_decision_backend import require_backend
        require_backend(judge.get("adapter"), "task")
        if judge.get("method", "ordinal-v1") not in ("ordinal-v1", "ordinal-v2", "choice-v2"):
            raise ValueError("本地 Judge method 无效")
        path = judge.get("modelPath")
        if not isinstance(path, str) or not path or len(path) > 4096:
            raise ValueError("本地 Judge 需要明确 modelPath；任务执行时不会隐式下载")
        if judge.get("device", "gpu") not in ("gpu", "metal", "cpu"):
            raise ValueError("本地 Judge device 无效")
        if judge.get("dtype", "float16") not in ("float16", "float32", "bfloat16"):
            raise ValueError("本地 Judge dtype 无效")
        source_model, revision = judge.get("sourceModel"), judge.get("revision")
        if not isinstance(source_model, str) or not source_model or len(source_model) > 256:
            raise ValueError("本地 Judge 需要明确 sourceModel")
        if (not isinstance(revision, str) or not revision or len(revision) > 128
                or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for char in revision)):
            raise ValueError("本地 Judge 需要固定且合法的 revision")
    return {"mode": "pool", "pool": pool, "fallback": fallback, "judge": judge,
        "threshold": number(task.get("threshold", .8), "task.threshold", 0, 1),
        "maxInputChars": number(task.get("maxInputChars", 12000), "task.maxInputChars", 512, 1000000, True),
        "maxExecutionOutputTokens": number(task.get("maxExecutionOutputTokens", 8192),
            "task.maxExecutionOutputTokens", 256, 1000000, True),
        "maxJudgeOutputTokens": number(task.get("maxJudgeOutputTokens", 1024),
            "task.maxJudgeOutputTokens", 64, 16384, True)}


def _escalation_config(raw, schema, declared_ids, roles):
    supplied = raw.get("escalation")
    if supplied is None:
        parameters = {**DEFAULTS, **raw.get("parameters", {})}
        return {"mode": "legacy", "initial": roles.get("efficient"),
            "takeover": roles.get("capable"),
            "judge": {"type": "llm", "modelId": roles.get("classifier")},
            "stallConfirmations": parameters["confirmations"], "threshold": .8,
            "judgeTimeoutMs": 30000, "maxJudgeInputBytes": 65536,
            "maxExecutionOutputTokens": 8192, "maxJudgeOutputTokens": 1024}
    if schema not in (SCHEMA_V4, SCHEMA_V5, SCHEMA_V6, SCHEMA_V7):
        raise ValueError(f"Escalation 独立设置需要 {SCHEMA_V4}")
    value = obj(supplied, ("initial", "takeover", "judge", "stallConfirmations", "threshold",
        "judgeTimeoutMs", "maxJudgeInputBytes", "maxExecutionOutputTokens", "maxJudgeOutputTokens"),
        "escalation")
    initial, takeover = value.get("initial"), value.get("takeover")
    if initial not in declared_ids or takeover not in declared_ids:
        raise ValueError("escalation.initial/takeover 必须引用已配置模型")
    if initial == takeover:
        raise ValueError("Escalation 起始模型与接管模型不能相同")
    judge = obj(value.get("judge", {}), ("type", "modelId", "adapter", "modelPath", "sourceModel",
        "revision", "device", "dtype", "method"), "escalation.judge")
    judge_type = judge.get("type")
    if judge_type == "llm":
        if judge.get("modelId") not in declared_ids:
            raise ValueError("Escalation 轻量 LLM Judge 必须引用已配置模型")
    elif judge_type == "local-decision":
        from .local_decision_backend import require_backend
        require_backend(judge.get("adapter"), "escalation")
        path = judge.get("modelPath")
        if not isinstance(path, str) or not path or len(path) > 4096:
            raise ValueError("Escalation 本地 Judge 需要明确 modelPath")
        if judge.get("device", "gpu") not in ("gpu", "metal", "cpu"):
            raise ValueError("Escalation 本地 Judge device 无效")
        if judge.get("dtype", "float16") not in ("float16", "float32", "bfloat16"):
            raise ValueError("Escalation 本地 Judge dtype 无效")
        source_model, revision = judge.get("sourceModel"), judge.get("revision")
        if not isinstance(source_model, str) or not source_model or len(source_model) > 256:
            raise ValueError("Escalation 本地 Judge 需要明确 sourceModel")
        if (not isinstance(revision, str) or not revision or len(revision) > 128
                or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
                       for char in revision)):
            raise ValueError("Escalation 本地 Judge 需要固定且合法的 revision")
    elif judge_type != "jev":
        raise ValueError("escalation.judge.type 必须是 llm、local-decision 或 jev")
    return {"mode": "configured", "initial": initial, "takeover": takeover, "judge": judge,
        "stallConfirmations": number(value.get("stallConfirmations", 2),
            "escalation.stallConfirmations", 1, 100, True),
        "threshold": number(value.get("threshold", .8), "escalation.threshold", 0, 1),
        "judgeTimeoutMs": number(value.get("judgeTimeoutMs", 30000),
            "escalation.judgeTimeoutMs", 100, 300000, True),
        "maxJudgeInputBytes": number(value.get("maxJudgeInputBytes", 65536),
            "escalation.maxJudgeInputBytes", 1024, MAX_CONFIG_BYTES, True),
        "maxExecutionOutputTokens": number(value.get("maxExecutionOutputTokens", 8192),
            "escalation.maxExecutionOutputTokens", 256, 1000000, True),
        "maxJudgeOutputTokens": number(value.get("maxJudgeOutputTokens", 1024),
            "escalation.maxJudgeOutputTokens", 64, 16384, True)}


def _advisor_config(raw, schema, declared_ids, roles):
    supplied = raw.get("advisor")
    if supplied is None:
        return {"mode": "legacy", "judge": {"type": "llm", "modelId": roles.get("advisor")},
                "threshold": .8, "judgeTimeoutMs": 30000, "maxJudgeInputBytes": 65536}
    if schema not in (SCHEMA_V5, SCHEMA_V6, SCHEMA_V7):
        raise ValueError(f"Advisor 独立 Judge 设置需要 {SCHEMA_V5} 或 {SCHEMA_V6}")
    allowed = ("judge", "threshold", "judgeTimeoutMs", "maxJudgeInputBytes",
               "allowExperimental")
    if schema in (SCHEMA_V6, SCHEMA_V7):
        allowed += ("executor", "maxExecutionOutputTokens", "maxJudgeOutputTokens")
    value = obj(supplied, allowed, "advisor")
    executor = value.get("executor", roles.get("efficient"))
    if executor not in declared_ids:
        raise ValueError("Advisor 执行模型必须引用已配置模型")
    judge = obj(value.get("judge", {}), ("type", "modelId", "adapter", "modelPath", "sourceModel",
        "revision", "device", "dtype", "method"), "advisor.judge")
    if judge.get("type") == "llm":
        if judge.get("modelId") not in declared_ids:
            raise ValueError("Advisor LLM Judge 必须引用已配置模型")
    elif judge.get("type") == "local-decision":
        from .local_decision_backend import require_backend
        require_backend(judge.get("adapter"), "advisor")
        for field, maximum in (("modelPath", 4096), ("sourceModel", 256), ("revision", 128)):
            if not isinstance(judge.get(field), str) or not judge[field] or len(judge[field]) > maximum:
                raise ValueError(f"Advisor 本地 Judge 缺少有效 {field}")
        if any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
               for char in judge["revision"]):
            raise ValueError("Advisor Judge revision 无效")
        if judge.get("device", "gpu") not in ("gpu", "metal", "cpu") or judge.get("dtype", "float16") not in ("float16", "float32", "bfloat16"):
            raise ValueError("Advisor Judge device/dtype 无效")
        if value.get("allowExperimental") is not True:
            raise ValueError("Advisor 本地 Judge 尚待专项验收；需明确启用实验模式")
    elif judge.get("type") != "jev":
        raise ValueError("advisor.judge.type 必须是 llm、local-decision 或 jev")
    return {"mode": "configured", "flow": "gate-v2" if schema in (SCHEMA_V6, SCHEMA_V7) else "legacy",
        "executor": executor, "judge": judge,
        "allowExperimental": value.get("allowExperimental") is True,
        "threshold": number(value.get("threshold", .8), "advisor.threshold", 0, 1),
        "judgeTimeoutMs": number(value.get("judgeTimeoutMs", 30000), "advisor.judgeTimeoutMs", 100, 300000, True),
        "maxJudgeInputBytes": number(value.get("maxJudgeInputBytes", 65536),
            "advisor.maxJudgeInputBytes", 1024, MAX_CONFIG_BYTES, True),
        "maxExecutionOutputTokens": number(value.get("maxExecutionOutputTokens", 8192),
            "advisor.maxExecutionOutputTokens", 256, 1000000, True),
        "maxJudgeOutputTokens": number(value.get("maxJudgeOutputTokens", 1024),
            "advisor.maxJudgeOutputTokens", 64, 16384, True),
        "maxReviews": 2 if schema in (SCHEMA_V6, SCHEMA_V7) else None,
        "maxRedos": 1 if schema in (SCHEMA_V6, SCHEMA_V7) else None}


def _stage_config(raw):
    supplied = raw.get("stage")
    if supplied is None:
        return {"mode": "rules"}
    if raw["schemaVersion"] not in (SCHEMA_V5, SCHEMA_V6, SCHEMA_V7):
        raise ValueError("Stage 独立设置需要 planning v5 或 v6")
    stage = obj(supplied, ("mode", "judge", "allowExperimental", "window", "interval",
        "maxJudgements", "holdTurns", "downgradeConfirmations", "upgradeThreshold",
        "downgradeThreshold", "judgeTimeoutMs", "maxJudgeInputBytes"), "stage")
    if stage.get("mode") == "rules":
        return {"mode": "rules"}
    if stage.get("mode") != "hybrid":
        raise ValueError("stage.mode 必须是 rules 或 hybrid")
    judge = obj(stage.get("judge", {}), ("type", "adapter", "modelPath", "sourceModel",
        "revision", "device", "dtype", "method"), "stage.judge")
    if judge.get("type") not in ("local-decision", "jev"):
        raise ValueError("Stage 协作模式需要本地或 Jev Judge")
    if judge["type"] == "local-decision":
        from .local_decision_backend import require_backend
        require_backend(judge.get("adapter"), "stage")
        for field, maximum in (("modelPath", 4096), ("sourceModel", 256), ("revision", 128)):
            if not isinstance(judge.get(field), str) or not judge[field] or len(judge[field]) > maximum:
                raise ValueError(f"Stage 本地 Judge 缺少有效 {field}")
        if any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-" for c in judge["revision"]):
            raise ValueError("Stage Judge revision 无效")
        if judge.get("device", "gpu") not in ("gpu", "metal", "cpu") or judge.get("dtype", "float16") not in ("float16", "float32", "bfloat16"):
            raise ValueError("Stage Judge device/dtype 无效")
    if type(stage.get("allowExperimental", False)) is not bool:
        raise ValueError("stage.allowExperimental 必须是布尔值")
    result = {"mode": "hybrid", "judge": judge, "allowExperimental": stage.get("allowExperimental", False)}
    for key, default, low, high in (("window", 3, 1, 100), ("interval", 2, 1, 100),
            ("maxJudgements", 4, 1, 100), ("holdTurns", 2, 1, 100),
            ("downgradeConfirmations", 2, 2, 100), ("judgeTimeoutMs", 30000 if judge["type"] == "jev" else 1000, 100, 30000),
            ("maxJudgeInputBytes", 65536, 512, MAX_CONFIG_BYTES)):
        result[key] = number(stage.get(key, default), f"stage.{key}", low, high, True)
    for key, default in (("upgradeThreshold", .8), ("downgradeThreshold", .9)):
        result[key] = number(stage.get(key, default), f"stage.{key}", .5, 1)
    if result["downgradeThreshold"] < result["upgradeThreshold"]:
        raise ValueError("Stage 降档门槛不能低于升级门槛")
    return result


def _composite_config(raw, schema, declared_ids, roles):
    supplied = raw.get("composite")
    if supplied is None:
        parameters = {**DEFAULTS, **raw.get("parameters", {})}
        return {"mode": "legacy", "task": _task_config(raw, schema, declared_ids, roles),
            "takeover": roles.get("capable"), "stage": {"mode": "rules",
                "window": parameters["window"], "threshold": parameters["threshold"],
                "holdTurns": parameters["holdTurns"]}}
    if schema not in (SCHEMA_V6, SCHEMA_V7):
        raise ValueError(f"Composite 独立设置需要 {SCHEMA_V6}")
    value = obj(supplied, ("pool", "takeover", "judge", "threshold", "maxInputChars",
        "maxExecutionOutputTokens", "maxJudgeOutputTokens", "stage"), "composite")
    takeover = value.get("takeover")
    task_raw = {"task": {"pool": value.get("pool"), "fallback": takeover,
        "judge": value.get("judge"), "threshold": value.get("threshold", .8),
        "maxInputChars": value.get("maxInputChars", 12000),
        "maxExecutionOutputTokens": value.get("maxExecutionOutputTokens", 8192),
        "maxJudgeOutputTokens": value.get("maxJudgeOutputTokens", 1024)}}
    task = _task_config(task_raw, schema, declared_ids, roles)
    stage_raw = obj(value.get("stage", {}), ("mode", "judge", "allowExperimental",
        "window", "threshold", "interval", "maxJudgements", "holdTurns",
        "downgradeConfirmations", "upgradeThreshold", "downgradeThreshold",
        "judgeTimeoutMs", "maxJudgeInputBytes"), "composite.stage")
    stage_mode = stage_raw.get("mode", "rules")
    if stage_mode == "rules":
        stage = {"mode": "rules",
            "window": number(stage_raw.get("window", 3), "composite.stage.window", 1, 100, True),
            "threshold": number(stage_raw.get("threshold", .5), "composite.stage.threshold", 0, 1),
            "holdTurns": number(stage_raw.get("holdTurns", 2), "composite.stage.holdTurns", 1, 100, True)}
    elif stage_mode == "hybrid":
        hybrid = dict(stage_raw)
        hybrid.pop("threshold", None)
        stage = _stage_config({"schemaVersion": schema, "stage": hybrid})
        if not stage["allowExperimental"]:
            raise ValueError("Composite Stage 协作判别尚待专项验收；需明确启用实验模式")
    else:
        raise ValueError("composite.stage.mode 必须是 rules 或 hybrid")
    return {"mode": "configured", "task": task, "takeover": takeover, "stage": stage}


def compile_config(raw):
    raw = deepcopy(obj(raw, ("schemaVersion", "enabled", "defaultStrategy", "billingUnit",
        "maxProductionCost", "maxProductionCostByUnit", "timeoutMs", "maxCalls", "models", "roles", "parameters",
        "security", "trustPolicies", "compatiblePairs", "task", "escalation", "advisor", "stage",
        "composite", "mediaRoutes", "jev", "maxReferenceCost"), "planningRouting"))
    if raw.get("schemaVersion") not in (SCHEMA, SCHEMA_V2, SCHEMA_V3, SCHEMA_V4, SCHEMA_V5, SCHEMA_V6, SCHEMA_V7) or type(raw.get("enabled")) is not bool:
        raise ValueError("需要版本化 planningRouting 配置和 enabled")
    if raw["schemaVersion"] == SCHEMA and ("maxProductionCostByUnit" in raw or any(
            isinstance(model, dict) and "billingUnit" in model for model in raw.get("models", []))):
        raise ValueError(f"多计费单位配置需要 {SCHEMA_V2}")
    if raw["schemaVersion"] == SCHEMA_V7:
        if raw.get("billingUnit") != "CNY":
            raise ValueError("金额版规划路由必须使用 CNY 预算")
        if set(raw.get("maxProductionCostByUnit", {})) - {"CNY"}:
            raise ValueError("金额版不接受 AFP 或 USD 预算；原币价格在模型记录中保留")
        for route in [*raw.get("models", []), *raw.get("mediaRoutes", [])]:
            if not isinstance(route, dict):
                raise ValueError("金额版模型与媒体路线必须为对象")
            if route.get("billingUnit", "CNY") not in ("CNY", "USD"):
                raise ValueError("金额版不能执行 AFP 路线；请先配置对应公开金额价格")
    reference_limit = raw.get("maxReferenceCost")
    if reference_limit is not None:
        if raw["schemaVersion"] != SCHEMA_V7:
            raise ValueError("参考成本预算需要 v7 配置")
        number(reference_limit, "maxReferenceCost")
    strategy = raw.get("defaultStrategy", "stage")
    if strategy not in STRATEGIES:
        raise ValueError("未知规划路由策略")
    unit = raw.get("billingUnit", "USD" if raw["schemaVersion"] == SCHEMA else "CNY")
    if unit not in ("USD", "AFP", "CNY"):
        raise ValueError("不支持的计费单位")
    fx_rate, fx_snapshot = frozen_usd_cny_rate()
    source_unit = unit
    if unit == "USD":
        unit = "CNY"
    # 未启用时仍允许保存未完成的设置；执行前必须通过完整预检。
    budget = raw.get("maxProductionCost")
    if budget is not None:
        number(budget, "maxProductionCost")
    unit_budgets = obj(raw.get("maxProductionCostByUnit", {}), ("USD", "AFP", "CNY"), "maxProductionCostByUnit")
    budgets = {}
    for name in ("AFP", "CNY"):
        if name in unit_budgets:
            budgets[name] = number(unit_budgets[name], f"{name} 生产预算")
    if "USD" in unit_budgets and "CNY" not in budgets:
        budgets["CNY"] = number(unit_budgets["USD"], "USD 生产预算") * fx_rate
    if budget is not None:
        amount = number(budget, "maxProductionCost")
        target = "CNY" if source_unit == "USD" else source_unit
        budgets.setdefault(target, amount * (fx_rate if source_unit == "USD" else 1))
    timeout = number(raw.get("timeoutMs", 300000), "timeoutMs", 0, 7200000, True)
    max_calls = number(raw.get("maxCalls", 128), "maxCalls", 0, 4096, True)
    policies = {}
    for item in raw.get("trustPolicies", []):
        p = obj(item, ("id", "residency", "auditLogging", "allowsSensitiveData", "expiresOn"), "trustPolicy")
        if not p.get("id") or p["id"] in policies or not p.get("residency"):
            raise ValueError("信任策略需要唯一 id 与 residency")
        if p.get("auditLogging") is not True or p.get("allowsSensitiveData") is not True:
            raise ValueError("信任策略必须明确允许敏感数据和审计")
        if p.get("expiresOn") and date.fromisoformat(p["expiresOn"]) < date.today():
            raise ValueError("信任策略已过期")
        policies[p["id"]] = p
    jev_raw = obj(raw.get("jev", {}), ("route", "credentialRef", "deployment", "trustPolicy", "actionGate"), "jev")
    from .jev_transport import route_spec
    jev_spec = route_spec(jev_raw.get("route", "typesafe"))
    jev_deployment = jev_raw.get("deployment", "external-cloud")
    if jev_deployment not in ("external-cloud", "trusted-cloud"):
        raise ValueError("Jev 是云端服务；部署域只能是外部云或受信任云")
    if jev_deployment == "trusted-cloud" and jev_raw.get("trustPolicy") not in policies:
        raise ValueError("Jev 可信云需要有效的信任策略")
    credential_ref = jev_raw.get("credentialRef", jev_spec["credentialRef"])
    if (not isinstance(credential_ref, str) or not credential_ref or len(credential_ref) > 128
            or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-/" for c in credential_ref)):
        raise ValueError("Jev 凭证引用无效；设置中只能保存引用，不能保存密钥")
    from .jev_choice_gate import VERSION as jev_gate_version
    if jev_raw.get("actionGate") not in (None, jev_gate_version):
        raise ValueError("Jev 动作门槛版本不兼容")
    jev = {**jev_spec, "credentialRef": credential_ref, "deployment": jev_deployment,
           "trustPolicy": jev_raw.get("trustPolicy"), "actionGate": jev_raw.get("actionGate"),
           "fxRate": fx_rate, "fxSource": fx_snapshot["source"], "fxAsOf": fx_snapshot["as_of"]}
    models = {}
    model_issues = {}
    declared_ids = set()
    for item in raw.get("models", []):
        m = obj(item, ("id", "provider", "model", "contextWindow", "maxOutputTokens",
            "inputPer1k", "outputPer1k", "cachedInputPer1k", "cacheWritePer1k", "reasoningEffort",
            "deployment", "trustPolicy", "capabilityCard", "billingUnit", "capabilities",
            "billingMode", "referencePricing"), "model")
        model_id = m.get("id")
        if not isinstance(model_id, str) or not model_id.strip() or len(model_id) > 256:
            raise ValueError("model.id 无效")
        if model_id in declared_ids:
            raise ValueError("重复模型")
        declared_ids.add(model_id)
        if m.get("provider") == "refractagent":
            raise ValueError("重复模型或递归路由")
        try:
            for field in ("provider", "model"):
                if not isinstance(m.get(field), str) or not m[field].strip() or len(m[field]) > 256:
                    raise ValueError(f"model.{field} 无效")
            deployment = m.get("deployment", "external-cloud")
            model_unit = m.get("billingUnit", source_unit)
            if model_unit not in ("USD", "AFP", "CNY"):
                raise ValueError("model.billingUnit 无效")
            if deployment not in ("local", "external-cloud", "trusted-cloud"):
                raise ValueError("规划路由需要真实部署域")
            if deployment == "trusted-cloud" and m.get("trustPolicy") not in policies:
                raise ValueError("可信云需要有效的信任策略")
            billing_mode = m.get('billingMode', 'metered')
            if billing_mode not in ('metered', 'subscription'):
                raise ValueError('未知计费模式')
            if billing_mode == 'subscription':
                if reference_limit is None:
                    raise ValueError('订阅金额估值需要明确参考成本上限')
                from .currency_pricing import PriceSnapshot, subscription_valuation, reference_price
                reference = obj(m.get('referencePricing'), ('executionEndpoint', 'price', 'mapping', 'schedule'), 'referencePricing')
                snapshot = reference_price(reference)
                if reference.get('schedule') and snapshot.currency != 'CNY':
                    raise ValueError('参考阶梯目前需要 CNY 价格')
                subscription_valuation({'provider': m['provider'], 'model': m['model'],
                    'endpoint': reference.get('executionEndpoint'), 'billingMode': 'subscription'},
                    snapshot, {}, mapping=reference.get('mapping'),
                    usd_cny={'base': 'USD', 'quote': 'CNY', 'rate': fx_rate,
                             'source': fx_snapshot['source'], 'asOf': fx_snapshot['as_of']})
                if model_unit != snapshot.currency:
                    raise ValueError('参考价格币种与模型计价单位不一致')
                rates = dict(snapshot.rates)
                if set(rates) - {'input', 'cachedInput', 'cacheWrite', 'output', 'request'} or rates.get('request', 0):
                    raise ValueError('当前文本估值尚不支持附加请求或媒体价格')
                m = {**m, 'inputPer1k': float(rates['input'] * 1000),
                     'outputPer1k': float(rates['output'] * 1000),
                     'cachedInputPer1k': float(rates.get('cachedInput', rates['input']) * 1000),
                     'cacheWritePer1k': float(rates.get('cacheWrite', rates['input']) * 1000)}
            context = number(m.get("contextWindow"), "contextWindow", 512, 10000000, True)
            output = number(m.get("maxOutputTokens"), "maxOutputTokens", 1, context - 1, True)
            input_price = number(m.get("inputPer1k"), "inputPer1k")
            output_price = number(m.get("outputPer1k"), "outputPer1k")
            cached = number(m.get("cachedInputPer1k", input_price), "cachedInputPer1k", 0, input_price)
            cache_write = m.get("cacheWritePer1k")
            if cache_write is not None:
                number(cache_write, "cacheWritePer1k")
            effort = m.get("reasoningEffort")
            if effort is not None and (not isinstance(effort, str) or not effort or effort.startswith("rr:")):
                raise ValueError("角色推理等级不能使用虚拟策略标识")
            card = m.get("capabilityCard", "")
            if not isinstance(card, str) or len(card) > 16000:
                raise ValueError("capabilityCard 无效")
            converted = model_unit == "USD"
            capabilities = _capabilities(m.get("capabilities"))
            models[model_id] = PlanningModel(model_id, m["provider"],
                input_price * (fx_rate if converted else 1), output_price * (fx_rate if converted else 1), 0,
                billing_unit="CNY" if converted else model_unit, api_model=m["model"], billing_mode=billing_mode,
                cached_input_cost_per_1k=cached * (fx_rate if converted else 1),
                context_window=context, max_output_tokens=output, wire_api="chat-completions",
                request_options=({"reasoning_effort": effort} if effort else {}),
                deployment=deployment, trust_policy=m.get("trustPolicy"),
                cache_write_cost_per_1k=cache_write * (fx_rate if converted and cache_write is not None else 1)
                    if cache_write is not None else None,
                source_billing_unit="USD" if converted else None,
                conversion_rate=fx_rate if converted else None,
                conversion_source=fx_snapshot["source"] if converted else None,
                conversion_as_of=fx_snapshot["as_of"] if converted else None,
                capabilities=capabilities, capability_card=card, reference_pricing=m.get('referencePricing'))
        except (ValueError, TypeError, KeyError) as exc:
            model_issues[model_id] = str(exc)
    roles = obj(raw.get("roles", {}), ("efficient", "capable", "classifier", "advisor"), "roles")
    for value in roles.values():
        if not isinstance(value, str) or value not in declared_ids:
            raise ValueError("角色引用不存在的模型")
    task = _task_config(raw, raw["schemaVersion"], declared_ids, roles)
    composite = _composite_config(raw, raw["schemaVersion"], declared_ids, roles)
    escalation = _escalation_config(raw, raw["schemaVersion"], declared_ids, roles)
    advisor = _advisor_config(raw, raw["schemaVersion"], declared_ids, roles)
    media_routes = raw.get("mediaRoutes", [])
    if not isinstance(media_routes, list) or len(media_routes) > 32:
        raise ValueError("mediaRoutes 无效")
    normalized_media = []
    media_ids = set()
    for route in media_routes:
        row = obj(route, ("id", "provider", "credentialProvider", "model", "operations", "billingUnit", "pricing",
            "deployment", "trustPolicy", "verified", "verification", "endpoint", "billingMode", "referencePricing"), "mediaRoute")
        if any(not isinstance(row.get(key), str) or not row[key] for key in ("id", "provider", "model")):
            raise ValueError("mediaRoute 需要 id/provider/model")
        if row["id"] in media_ids:
            raise ValueError("mediaRoute.id 不得重复")
        media_ids.add(row["id"])
        operations = row.get("operations")
        allowed_operations = ("image-understand", "video-understand", "image-generate", "image-edit",
                              "video-generate", "image-to-video")
        if (not isinstance(operations, list) or not operations or len(set(operations)) != len(operations)
                or any(operation not in allowed_operations for operation in operations)):
            raise ValueError("mediaRoute.operations 无效")
        verification = row.get("verification", "verified" if row.get("verified") is True else "declared")
        if verification not in TASK_CAPABILITY_LEVELS:
            raise ValueError("mediaRoute.verification 状态无效")
        credential_provider = row.get("credentialProvider", row["provider"])
        if (not isinstance(credential_provider, str) or not credential_provider or len(credential_provider) > 128
                or any(char not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
                       for char in credential_provider)):
            raise ValueError("mediaRoute.credentialProvider 无效")
        deployment = row.get("deployment", "external-cloud")
        if deployment not in ("local", "external-cloud", "trusted-cloud"):
            raise ValueError("mediaRoute.deployment 无效")
        if deployment == "trusted-cloud" and row.get("trustPolicy") not in policies:
            raise ValueError("可信媒体路线需要有效的信任策略")
        route_unit = row.get("billingUnit")
        if route_unit not in ("AFP", "CNY", "USD"):
            raise ValueError("mediaRoute.billingUnit 无效")
        pricing = obj(row.get("pricing", {}), ("basis", "unitCost", "source", "checkedAt"),
                      "mediaRoute.pricing")
        if pricing.get("basis") not in ("image", "output-10k-token", "second"):
            raise ValueError("mediaRoute.pricing.basis 无效")
        unit_cost = number(pricing.get("unitCost"), "mediaRoute.pricing.unitCost")
        if any(not isinstance(pricing.get(name), str) or not pricing[name]
               for name in ("source", "checkedAt")):
            raise ValueError("媒体价格需要来源与查证日期")
        endpoint = row.get("endpoint")
        if not isinstance(endpoint, str) or not endpoint.startswith("https://"):
            raise ValueError("媒体路线需要明确 HTTPS endpoint")
        if route_unit == "AFP" and (row.get("provider") != "ark-plan"
                or endpoint.rstrip("/") != "https://ark.cn-beijing.volces.com/api/plan/v3"):
            raise ValueError("AFP 媒体路线必须使用 Ark Agent Plan 专属端点")
        media_mode = row.get('billingMode', 'metered')
        if media_mode not in ('metered', 'subscription'):
            raise ValueError('mediaRoute.billingMode 无效')
        if media_mode == 'subscription':
            if raw['schemaVersion'] != SCHEMA_V7 or reference_limit is None:
                raise ValueError('订阅媒体需要新版参考成本账本')
            from .currency_pricing import reference_price, subscription_valuation
            reference = row.get('referencePricing', {})
            price = reference_price(reference)
            if reference.get('executionEndpoint', '').rstrip('/') != endpoint.rstrip('/'):
                raise ValueError('媒体参考价格与实际端点不匹配')
            subscription_valuation({'provider': row['provider'], 'model': row['model'],
                'endpoint': endpoint, 'billingMode': 'subscription'}, price, {}, mapping=reference.get('mapping'))
            if (price.currency != route_unit or pricing['basis'] != 'image'
                    or set(dict(price.rates)) != {'image'}
                    or float(dict(price.rates)['image']) != unit_cost):
                raise ValueError('媒体价格与参考快照不一致')
        normalized_media.append({**row, "deployment": deployment,
            "credentialProvider": credential_provider, "verification": verification,
            "billingUnit": "CNY" if route_unit == "USD" else route_unit,
            "pricing": {**pricing, "unitCost": unit_cost * (fx_rate if route_unit == "USD" else 1)},
            **({"sourceBillingUnit": "USD", "conversionRate": fx_rate,
                "conversionSource": fx_snapshot["source"], "conversionAsOf": fx_snapshot["as_of"]}
               if route_unit == "USD" else {})})
    parameters = {**DEFAULTS, **obj(raw.get("parameters", {}), DEFAULTS, "parameters")}
    for key in ("window", "holdTurns", "maxReviews", "maxRedos", "stallTurns", "confirmations", "seed"):
        number(parameters[key], key, 1 if key in ("window", "confirmations") else 0, 10000, True)
    for key in ("threshold", "baseThreshold", "thresholdStep"):
        number(parameters[key], key, 0, 1)
    if parameters["baseThreshold"] + 2 * parameters["thresholdStep"] > 1:
        raise ValueError("能力边界阈值超过 1")
    for key in ("efficientWeight", "capableWeight"):
        number(parameters[key], key)
    if parameters["staticMode"] not in ("fixed", "random") or parameters["efficientWeight"] + parameters["capableWeight"] <= 0:
        raise ValueError("静态策略参数无效")
    security_raw = obj(raw.get("security", {}), ("sensitiveTerms", "maxPromptBytes"), "security")
    security = compile_privacy({"enabled": True, **security_raw}, models=tuple(models.values()),
        schema_version=PRIVACY_SCHEMA_V2, require_local_candidate=False, enforce_zero_cost_classifier=False)
    pairs = raw.get("compatiblePairs", [])
    if not isinstance(pairs, list) or any(not isinstance(p, list) or len(p) != 2
            or any(v not in declared_ids for v in p) for p in pairs):
        raise ValueError("compatiblePairs 必须引用两个已配置模型")
    return {"raw": raw, "enabled": raw["enabled"], "strategy": strategy, "unit": unit, "budget": budget,
        "timeout": timeout, "max_calls": max_calls, "models": models, "roles": roles,
        "parameters": parameters, "security": security, "pairs": pairs, "budgets": budgets,
        "task": task, "composite": composite, "escalation": escalation, "advisor": advisor,
        "stage": _stage_config(raw), "jev": jev, "media_routes": normalized_media,
        "model_issues": model_issues, "reference_limit": reference_limit}


def preview(raw, host_issues=None):
    try:
        c = compile_config(raw)
    except (ValueError, TypeError, KeyError) as exc:
        return {"valid": False, "issues": [str(exc)], "strategies": []}
    def task_route_issues(route, label):
        issues = []
        for model_id in route["pool"]:
            if model_id in c["model_issues"]:
                issues.append(f"{label} 候选 {model_id} 配置未完成（{c['model_issues'][model_id]}）")
            elif model_id in (host_issues or {}):
                issues.append(f"{label} 候选 {model_id}：{host_issues[model_id]}")
            else:
                model = c["models"][model_id]
                if not model.capabilities.get("mainExecutor"):
                    issues.append(f"{label} 候选 {model_id} 不能主持 Agent 执行")
                if model.billing_unit not in c["budgets"]:
                    issues.append(f"{label} 候选 {model_id} 缺少 {model.billing_unit} 生产预算")
        fallback = route["fallback"]
        if fallback in c["models"] and not c["models"][fallback].capabilities.get("mainExecutor"):
            issues.append(f"{label} 指定接管模型不能主持 Agent 执行")
        judge = route["judge"]
        if judge["type"] == "llm":
            judge_id = judge["modelId"]
            if judge_id in c["model_issues"]:
                issues.append(f"{label} Judge {judge_id} 配置未完成（{c['model_issues'][judge_id]}）")
            elif judge_id in (host_issues or {}):
                issues.append(f"{label} Judge {judge_id}：{host_issues[judge_id]}")
            elif c["models"][judge_id].billing_unit not in c["budgets"]:
                issues.append(f"{label} 缺少 {c['models'][judge_id].billing_unit} 生产预算")
        elif judge["type"] == "local-decision":
            path = Path(judge["modelPath"]).expanduser()
            try:
                manifest = json.loads((path / "refractrouter-laya.json").read_text())
            except (OSError, ValueError, TypeError):
                manifest = {}
            if (not path.is_dir() or not all((path / name).exists()
                    for name in ("model.safetensors", "mlx_config.json",
                                 "rl_agent_config.json", "encoder/config.json"))
                    or manifest.get("sourceModel") != judge["sourceModel"]
                    or manifest.get("revision") != judge["revision"]):
                issues.append(f"{label} 本地 Task Judge 权重或固定 revision 尚未核对")
        elif "CNY" not in c["budgets"]:
            issues.append(f"{label} Jev 需要 CNY 生产预算（官方 USD 价格按冻结汇率折算）")
        if judge["type"] == "jev" and (host_issues or {}).get("__jev__"):
            issues.append(f"{label} Jev：{host_issues['__jev__']}")
        return issues

    rows = []
    for strategy in STRATEGIES:
        required = list(REQUIRED[strategy])
        if strategy == "task" and c["task"]["mode"] == "legacy":
            required = ["efficient", "capable", "classifier"]
        if strategy == "static" and c["parameters"]["staticMode"] == "random":
            required.append("capable")
        if strategy == "escalation":
            e = c["escalation"]
            required = [] if e["mode"] == "configured" else ["efficient", "capable", "classifier"]
        if strategy == "advisor" and c["advisor"]["mode"] == "configured":
            required = []
        if strategy == "composite" and c["composite"]["mode"] == "configured":
            required = []
        issues = [f"缺少 {r} 模型" for r in required if r not in c["roles"]]
        for role in required:
            model_id = c["roles"].get(role)
            if model_id in c["model_issues"]:
                reason = (host_issues or {}).get(model_id, c["model_issues"][model_id])
                issues.append(f"{role}：{model_id} 配置未完成（{reason}）")
            elif model_id in (host_issues or {}):
                issues.append(f"{role}：模型资料不可用（{host_issues[model_id]}）")
        for role in required:
            model_id = c["roles"].get(role)
            if model_id in c["models"]:
                model_unit = c["models"][model_id].billing_unit
                if model_unit not in c["budgets"]:
                    issues.append(f"缺少 {model_unit} 生产预算")
        if strategy == "task" and c["task"]["mode"] == "pool":
            issues.extend(task_route_issues(c["task"], "Task"))
        if strategy == "composite" and c["composite"]["mode"] == "configured":
            composite = c["composite"]
            issues.extend(task_route_issues(composite["task"], "Composite"))
            if composite["takeover"] != composite["task"]["fallback"]:
                issues.append("Composite Task 备援与接管模型必须相同")
            if composite["stage"]["mode"] == "hybrid":
                judge = composite["stage"]["judge"]
                if judge["type"] == "jev":
                    if "CNY" not in c["budgets"]:
                        issues.append("Composite Stage Jev 需要 CNY 生产预算")
                    if (host_issues or {}).get("__jev__"):
                        issues.append("Composite Stage Jev：" + host_issues["__jev__"])
                else:
                    path = Path(judge["modelPath"]).expanduser()
                    try:
                        manifest = json.loads((path / "refractrouter-laya.json").read_text())
                    except (OSError, ValueError, TypeError):
                        manifest = {}
                    if (not all((path / name).is_file() for name in ("model.safetensors", "mlx_config.json",
                            "rl_agent_config.json", "encoder/config.json"))
                            or manifest.get("revision") != judge["revision"]
                            or manifest.get("sourceModel") != judge["sourceModel"]):
                        issues.append("Composite 本地 Stage Judge 权重或固定 revision 尚未核对")
        if strategy == "escalation" and c["escalation"]["mode"] == "configured":
            e = c["escalation"]
            escalation_ids = [e["initial"], e["takeover"]]
            if e["judge"]["type"] == "llm":
                escalation_ids.append(e["judge"]["modelId"])
            for model_id in escalation_ids:
                if model_id in c["model_issues"]:
                    issues.append(f"Escalation 模型 {model_id} 配置未完成（{c['model_issues'][model_id]}）")
                elif model_id in (host_issues or {}):
                    issues.append(f"Escalation 模型 {model_id}：{host_issues[model_id]}")
                elif model_id in c["models"] and c["models"][model_id].billing_unit not in c["budgets"]:
                    issues.append(f"Escalation 模型 {model_id} 缺少 {c['models'][model_id].billing_unit} 生产预算")
            if e["judge"]["type"] == "jev":
                if "CNY" not in c["budgets"]:
                    issues.append("Escalation Jev 需要 CNY 生产预算")
                if (host_issues or {}).get("__jev__"):
                    issues.append("Escalation Jev：" + host_issues["__jev__"])
            if e["judge"]["type"] == "local-decision":
                judge = e["judge"]
                path = Path(judge["modelPath"])
                try:
                    manifest = json.loads((path / "refractrouter-laya.json").read_text())
                except (OSError, ValueError, TypeError):
                    manifest = {}
                if (not path.is_dir() or not all((path / name).exists()
                        for name in ("model.safetensors", "mlx_config.json",
                                     "rl_agent_config.json", "encoder/config.json"))
                        or manifest.get("sourceModel") != judge["sourceModel"]
                        or manifest.get("revision") != judge["revision"]):
                    issues.append("Escalation 本地 Judge 权重或固定 revision 尚未核对")
        if strategy == "advisor" and c["advisor"]["mode"] == "configured":
            advisor = c["advisor"]
            judge = advisor["judge"]
            executor_id = advisor["executor"]
            if executor_id in c["model_issues"]:
                issues.append(f"Advisor 执行模型 {executor_id} 配置未完成（{c['model_issues'][executor_id]}）")
            elif executor_id in (host_issues or {}):
                issues.append(f"Advisor 执行模型 {executor_id}：{host_issues[executor_id]}")
            elif executor_id in c["models"] and c["models"][executor_id].billing_unit not in c["budgets"]:
                issues.append(f"Advisor 执行模型缺少 {c['models'][executor_id].billing_unit} 生产预算")
            if judge["type"] == "llm":
                model_id = judge["modelId"]
                if model_id in c["model_issues"]:
                    issues.append(f"Advisor Judge {model_id} 配置未完成（{c['model_issues'][model_id]}）")
                elif model_id in (host_issues or {}):
                    issues.append(f"Advisor Judge {model_id}：{host_issues[model_id]}")
                elif model_id in c["models"] and c["models"][model_id].billing_unit not in c["budgets"]:
                    issues.append(f"Advisor Judge 缺少 {c['models'][model_id].billing_unit} 生产预算")
            elif judge["type"] == "local-decision":
                path = Path(judge["modelPath"]).expanduser()
                try:
                    manifest = json.loads((path / "refractrouter-laya.json").read_text())
                except (OSError, ValueError, TypeError):
                    manifest = {}
                if (not all((path / name).is_file() for name in ("model.safetensors", "mlx_config.json",
                        "rl_agent_config.json", "encoder/config.json")) or manifest.get("revision") != judge["revision"]
                        or manifest.get("sourceModel") != judge["sourceModel"]):
                    issues.append("Advisor 本地 Judge 权重或固定 revision 尚未核对")
            else:
                if "CNY" not in c["budgets"]:
                    issues.append("Advisor Jev 需要 CNY 生产预算")
                if (host_issues or {}).get("__jev__"):
                    issues.append("Advisor Jev：" + host_issues["__jev__"])
        if strategy == "stage" and c["stage"]["mode"] == "hybrid":
            if not c["stage"]["allowExperimental"]:
                issues.append("Stage 轨迹判别尚未通过日常质量验收；需明确启用实验模式")
            judge = c["stage"]["judge"]
            if judge["type"] == "jev":
                if "CNY" not in c["budgets"]:
                    issues.append("Stage Jev 需要 CNY 生产预算")
                if (host_issues or {}).get("__jev__"):
                    issues.append("Stage Jev：" + host_issues["__jev__"])
            else:
                path = Path(judge["modelPath"]).expanduser()
                try:
                    manifest = json.loads((path / "refractrouter-laya.json").read_text())
                except (OSError, ValueError, TypeError):
                    manifest = {}
                if (not all((path / name).is_file() for name in ("model.safetensors", "mlx_config.json",
                        "rl_agent_config.json", "encoder/config.json")) or manifest.get("revision") != judge["revision"]
                        or manifest.get("sourceModel") != judge["sourceModel"]):
                    issues.append("Stage 本地 Judge 权重或固定 revision 尚未核对")
        if not c["enabled"]:
            issues.append("尚未启用规划路由")
        rows.append({"id": strategy, "name": NAMES[strategy], "available": not issues, "issues": issues})
    config_issues = [f"{model_id} 配置未完成（{(host_issues or {}).get(model_id, reason)}）"
                     for model_id, reason in c["model_issues"].items()]
    media = []
    for route in c["media_routes"]:
        media_issues = []
        if route["verification"] != "verified":
            media_issues.append("尚未通过真实接口验收，受管工具不会派发")
        if route["billingUnit"] not in c["budgets"]:
            media_issues.append(f"缺少 {route['billingUnit']} 生产预算")
        media.append({"id": route["id"], "provider": route["provider"], "model": route["model"],
                      "operations": route["operations"], "verification": route["verification"],
                      "available": not media_issues, "issues": media_issues})
    return {"valid": True, "issues": config_issues, "strategies": rows, "mediaRoutes": media,
            "defaultStrategy": c["strategy"],
            "coverage": "仅受管模型调用；宿主工具和独立子 Agent 费用不在主任务硬预算内"}
