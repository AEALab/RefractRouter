# 质量协议的运行绑定与研究边界

对应 [Issue #52](https://github.com/AEALab/RefractRouter/issues/52)。本文说明实际运行的协议，
取代初版文档中尚未绑定的路线、提示、容量和统计建议。
`data/quality-study-v1/protocol.json` 继续作为历史材料版本的索引；
新入口生成的 `bound-quality-study-v1` 才是执行依据，不混用两个版本的路线名或上限。

## 这轮能够回答的问题

先验证固定材料上的质量检查和公平比较是否可执行，再检验达到预定质量门槛的路线中，
哪些在用户等待时间与 AFP 上互不支配。结果允许没有合格路线、没有收益或证据不足。

本轮材料为 18 个原创构造微任务，6 个开发任务、12 个候选留出任务。
三类任务分别覆盖直接处理、可并行与必须先后处理的结构，每个格子两题。
材料正文的 UTF-8 长度中位数为 219 字节；因此本轮限定为控制性探索，
不能据此推广到长文分析或真实业务分布。来源族、模板族及任务形态都是作者声明，
需要真人确认；不同 ID 和哈希不能证明语义独立。

新增的确定性复算器从原始材料的数字和显式约束重新计算，再与参考事实比较。
这能发现计算或参考表抄写错误；其中的自然语言到规则的形式化仍由作者编写，
不构成另一位独立材料审查者。开放语义、难度、代表性和用途适配仍须真人核验。
如果审查认为材料不适合目标用途，应补充或更换材料后重新冻结，不能直接勾选通过。

这也是 [#51 文献复核](https://github.com/AEALab/RefractRouter/wiki/12-GAP1文献复核与公平对照)
中本地控制基线的准备阶段。当前固定规则不声称复现 DAAO、FlowCompile、LLMCompiler、
MasRouter 或 AFlow，不作优于这些论文方法的主张。论文级优越性比较需要另行冻结忠实实现
与适配成本；不能把这里的零训练成本归给学习方法。

## 十二条实际路线

| 路线 | 实际行为 | 节点并发上限 |
|---|---|---:|
| `direct-cheap` / `direct-mid` / `direct-strong` | 对应固定模型一次完成交付 | 1 |
| `task-selector` | 小模型看公开任务，选择一个模型直接完成 | 1 个执行节点 |
| `random-mixture` | 预先按 cheap/strong 各 50% 抽签，抽签不看输入或结果 | 1 个执行节点 |
| `shared-single-1` / `shared-single-2` | 复用同一张图，全部节点使用 strong | 1 / 2 |
| `shared-heterogeneous-1` / `shared-heterogeneous-2` | 复用同一张图，按固定规则逐节点选模 | 1 / 2 |
| `auto-single` | 每次在线重新规划，全部节点使用 strong | 2 |
| `auto-heterogeneous` | 每次在线重新规划，按固定规则逐节点选模 | 2 |
| `direct-or-dag` | 小模型先选直接或 DAG，再执行对应路线 | 2 |

共享图的四条路线使用每任务一次生成的相同计划，全部重复继续使用该计划。
串行/并行之间的节点分配也相同，计划与公开任务均绑定哈希，缓存失效不重新生成。
因此它们可以隔离节点选模与并行执行的作用。自动路线允许每次生成不同图，
只比较完整用户体验，不把其差异称作“同图并行收益”。

异构规则明确冻结：最终节点、高难度或高风险节点使用 strong，其他中等节点使用 mid，
其余使用 cheap。它是无训练的启发式对照，没有实测能力最优保证。
cheap/mid/strong 是冻结 manifest 的候选别名，不是已认证的质量等级。
规划由 cheap 完成，最多六节点，包含最终汇总节点；任务简单时允许只生成一个节点。
初轮不启用规划修复、节点回退、动态再拆或基于留出反馈的策略更新。

## 公平输入、交付和时间口径

所有路线接收相同的五字段公开任务，使用相同最终 JSON 合同：`answer` 和 `findings`。
单条依赖边 `required_edge` 的公开说明统一为 `[前置步骤名称, 后续步骤名称]`，
名称不拼接状态词，实际通过条件仍须写在正文。所有路线统一容许剥离一个完整的外层
JSON 代码围栏；不修补字段、语义、截断或混杂说明，原始文本仍然归档。
完整正文没有额外字数限制；最终模型统一最多 8192 output tokens。
规划和选择各为 1200，中间节点及两种 judge 各为 2048。
实际请求按 UTF-8 字节数加封装余量检查输入容量，再按保守 token 上界预留 AFP。
这些容量不是预期输入长度，也不是预测费用。

私有参考只参与材料审核与运行后评分，不进入规划、选择、节点执行或在线 judge 的消息。
模型接口没有文件工具或源码目录访问入口。规划器能看到任务要求，不能看到 split、
任务形态标签或研究者期望的参考结论。测试检查真实发送路径的公共字段及最终合同。
真实消息、节点依赖、计划哈希与模型分配另有完整归档，可以逐条复核。

在线 AFP 包含选择、在线规划、全部节点、汇总及交付 judge；失败照计。
离线 AFP 单列共享图准备与独立研究 judge，不混成用户当次费用。
已有辅助校准的 52.190 AFP 属于历史研究准备；新增真实运行器验证费用另列。
画像探测、训练和搜索调用为零，是因为本轮方法根本没有这些步骤；研究总准备成本并非零。

等待时间从单次任务进入执行到交付 judge 完成或失败处理结束，以单调时钟实测。
它包含该次规划、节点队列、并行等待、汇总和在线评审，不用节点耗时之和代替。
同时记录计划就绪、正文就绪、节点事件与最终结束时间。
这是批处理入口的实测时间，未测量图形界面的首条进度展示或真人阅读时间。
共享图准备时间单列；摊销值只是成本分配情景，不能冒充真实冷启动端到端时间。

每阶段配置 timeout，路线 deadline 按最坏串行阶段合成并传入核心调度器。
超时、无效输出、停批与在途结算全部保留；timeout 之和不是经过硬中断验证的墙钟 SLA。
未知用量、认证、预算或账本异常停止整批，实际 AFP 为未知，不能填零。
已结算的任务输出错误仅停止该任务下游，继续预定的其他任务，禁止重跑到成功。

## 冻结的质量和统计含义

质量仍采用三态：关键事实错误为 `fail`，缺真人语义证据为 `pending`；
只有确定性关键检查通过且真实双审一致通过，或第三人裁决通过，才为 `pass`。
在线模型 judge 的通过只记为 `delivered-unconfirmed`，不能代签真人。

研究操作点固定为：至少 90% 的任务在三次重复中全部确认通过，
相对参考路线非劣容忍 5 个百分点，最小有用的时间或 AFP 改善 10%。
这里的统计单位是任务，不是把三次调用当三个样本；它比按调用汇总通过率更严格。
这些是可执行的研究操作定义，仍需真人确认是否符合用途，不能声称已证实用户能接受。
90% 的观察门槛与 90% 的总体置信保证是两件事。

12 个候选留出、每题三次重复，用于有限候选的探索，不保证总体非劣的检验能力。
质量下界采用精确二项反演；配对差使用候选独过/参考独过概率的上下界与并集界。
质量比较统一控制 0.05 的家族错误概率，12 条路线下界与两次配对比较的四个尾界
各分配 `0.05 / 16`。因此，12 题都通过也不会得到“总体至少 90%”的结论。
方法依据为 [NIST 二项比例区间](https://www.itl.nist.gov/div898/handbook/prc/section2/prc241.htm)。

主要比较固定为 `direct-or-dag` 对 `direct-strong`、对 `task-selector`。
时间和 AFP 先汇总任务内全部重复，再按来源族配对重采样 10000 次，种子 52053；
百分位区间只作探索诊断，退化区间明确标记，不解释成没有不确定性。
重采样使用完整相同的任务集合，缺失、未知费用或非有限时间会阻止比较。
相关方法说明见 [SciPy bootstrap 文档](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html)。

执行顺序固定种子 52052：重复轮交错，每任务每次重复内随机路线顺序；随机混合选择
提前写入完整 schedule。失败和待判定留在原分母，不只筛成功样本计算收益。
类别与结构分层作描述，不从其中挑选最有利的一组作为主结论。
确认质量不足时前沿为空；有真人确认后也只称“本批有限候选的经验前沿”，不称全局最优。

### #76 的每成功任务 AFP 口径

任务级 accepted 同时要求：该任务全部冻结重复均通过确定性检查与真人语义裁决，
且 #52 的独立材料审查和用途门槛已经完成。模型 judge、自评或缺少真人记录都不能
把任务写成 accepted；#52 未完成时已双审的任务也只能保留为 pending。

每条路线同时报告以下字段：

- adjudicated_pass_task_count：全部重复均通过任务级语义裁决的任务数，
  用于区分“任务本身已判过”和“#52 总门槛已激活”。
- accepted_task_count 与 quality_pass_rate：在 #52 门槛激活后的接受任务数及比例。
- total_afp_all_tasks：全部预定任务的在线执行、离线研究评审和共享图准备 AFP，
  失败、pending 和重试成本都保留在分子中。
- successful_sample_afp：仅通过质量门槛任务的 AFP，用作对照，不能替代主指标。
- afp_per_accepted_task：total_afp_all_tasks / accepted_task_count，
  是 #76 的主成本指标；没有 accepted 任务时为 null，不是 0。
- successful_sample_afp_per_accepted_task：仅成功样本 AFP 除以 accepted 任务数，
  用于展示“只看成功样本”会低估多少成本。

任一任务的 AFP 未知时，afp_per_accepted_task 与成本结论为 null / false，
不能把未知用量填为零。共享图准备按路线独立部署情景计入该路线的每任务一次准备成本；
这不是把一次实验中四条共享路线共用的准备相加成实验总支出。

真人复核时间通过材料审查、输出盲审和用途确认记录中的 review_time_ms 单独汇总，
缺失时报告 null 和缺失记录数，不计入模型 AFP，也不能从研究证据中消失。

## 留出门槛解锁与单一合流记录（2026-09-18）

12 题留出实验的放行门槛是本地多模型共识（MoA）材料评审加用途确认，不使用 Ark AFP。
解锁前卡在两处：

- decision-06：参考检查把有序字段 order 当成无序集合比较。一份依赖顺序被排错的候选
  因此被放行。修订把该检查改为有序比较，并在任务与参考的 semantic_criteria 同步写明
  「顺序必须满足全部依赖方向，并与 finish_minute 相互一致」，同时重算该题 task_sha256
  与 public/tasks.json、review/references.json 两个 artifact 哈希。
- decision-03：先是评审调用超时（claude 侧 480 秒内未返回）。超时通过运行级覆盖 900 秒
  解除，策略里的 480 秒保持不变，避免改变 MoA 策略摘要而让已通过记录失效。
  超时解除后的重审仍判 pending，原因是一处真实的材料歧义：s1 的硬条件是「无障碍通道」，
  s2 起初只对 A 写「无障碍通道」，对 B、D 写「有通道」、C 写「无通道」。若「有通道」不等同
  硬条件所指，D 就属于硬条件不合格，rejected_ids 应为 {B,C,D} 而不是参考的 {B,C}。
  修订只把 s2 的通道描述统一写成「有无障碍通道」／「无无障碍通道」，房间、容量、报价与
  参考答案一字未改，并重算该题 material_sha256、task_sha256 与两个 artifact 哈希。

其余 10 题的任务、参考与哈希一律未动，这 10 份已通过的记录按
task_sha256 / reference_sha256 / 六项 criterion 复核后直接复用；
只有 decision-03 与 decision-06 定向重跑。旧分片与新分片由
experiments/merge_moa_records.py 合成单一 records 文件（合流只做口径校验、
重复覆盖留痕与冻结顺序重排，不调用模型、不改写记录），门禁只读这一个文件。

本轮评审与冻结都绑定 `data/quality-study-v1`。两个版本的 12 题留出材料在修订前逐题相同
（task_sha256 一致），但 `data/quality-study-v2` 的 protocol.json 哈希已被已完成开发对照的
frozen.json 绑定，改动会让那批付费结果无法复算，因此本轮不动 v2：它的 decision-06 仍是无序
集合比较、decision-03 仍是旧文本。若今后改用 v2 跑留出，必须先同步本文两处修订并重新冻结。

用途确认载荷补齐了门槛语义，避免评审在解释空间里自由判定：

1. 门槛在路线结果产生之前冻结，并以冻结件哈希与任务级绑定哈希固定；
2. 90% 是按任务观测的操作门槛，同一任务三次重复全部通过才算该题通过；
3. 5 个百分点作用于配对质量差下界，不是观测差的直接比较；
4. 精确二项下界只是随报告给出的诊断下界，不参与通过判定；
5. 12 题全部通过也不得推断总体至少 90%，也不得声称用户可接受性；
6. 本轮放行靠本地多模型共识，它替代真人签署作为放行条件，但本身不是真人审查。

### 解锁结果与冻结（2026-09-18）

解锁在本机 codex / claude CLI 上完成，未产生 Ark AFP 消耗（评审不经过 Ark 账本）。

- 合流记录：`reports/quality-study-v2/moa-material-gate/moa-results.json`。12 题六项 criterion
  全部共识 pass（共识分布 pass 12 / fail 0 / pending 0，升级 0 条、无效记录 0 条）。
  被定向重审取代的旧结论在 `superseded` 字段与 README 逐条留痕：decision-06 pending → pass、
  decision-03 pending → pass；旧分片文件保留原样，便于复核。
- 用途确认：`reports/quality-study-v2/moa-purpose-06/`。两位初审
  （codex `ds/deepseek-v4-pro`、claude `opus`）逐项一致 pass，无升级、无失败记录。
- 门禁断言：`moa_gate(frozen, tasks, refs, 合流记录, 用途记录) is True`，且 12 题
  `task_bindings` 与冻结件逐题一致。
- 冻结件：`reports/pareto-holdout-v1/bound-01/frozen.json`。选择为 12 题留出 ×
  3 臂（`direct-strong`、`task-selector`、`direct-or-dag`）× 3 重复；`max_calls` 612、
  `online_afp_ceiling` 29523.4848、`offline_afp_ceiling` 14376.96、`schedule` 108、
  `setups` 0（非共享图路线不需要单独的准备记账）。
- 排练：`reports/pareto-holdout-v1/rehearsal-01/`。108 次运行、`actual_model_calls` 0、
  `actual_afp` 0，不发起网关请求，只验证编排、门槛接线与包络计数。

冻结之后，`src/refractrouter/` 下任意 `.py`、`experiments/*quality*.py`、`experiments/*pareto*.py`、
`pyproject.toml` 或 `uv.lock` 的改动都会让 `bound-01` 失效（`execute()` 会重算并比对冻结件）；
需要变化时按新一轮冻结与新输出目录处理，不追改已冻结件。

付费执行到本轮为止只登记、不执行，等待用户明确放行后再跑。登记范围与包络同冻结件；
参照旧运行（474 次调用、394.5 AFP）估计实际消耗约 400–550 AFP。主对比是
`direct-or-dag` 对 `direct-strong` 与 `direct-or-dag` 对 `task-selector`，主指标为
AFP per accepted task，时间与墙钟只作探索诊断。

### 重新冻结（bound-02，2026-09-18）

PR #97（隐私放置 A2）在 bound-01 冻结后改动了 `src/refractrouter/` 下五个被冻结哈希
绑定的文件（`agent.py`、`application_config.py`、`dynamic_decomposition.py`、
`task_execution.py`、`task_runtime.py`）。在当前实现上以 bound-01 重放排练会在
哈希绑定校验处触发 `ValueError: frozen protocol or implementation changed`，
bound-01 就此失效并保留原样，不追改。

- 新冻结件：`reports/pareto-holdout-v1/bound-02/frozen.json`。选择与 bound-01 完全
  一致：12 题留出 × 3 臂 × 3 重复，`max_calls` 612、`online_afp_ceiling` 29523.4848、
  `offline_afp_ceiling` 14376.96；冻结过程零模型调用、零 AFP。
- 新排练：`reports/pareto-holdout-v1/rehearsal-02/`。108 次运行、状态 completed、
  `actual_model_calls` 0、`actual_afp` 0、墙钟约 40.2 秒；MoA 门禁证据复用 #96 的
  合流材料评审与 moa-purpose-06 用途确认，未产生新的评审调用。
- 付费执行继续只登记、不执行，等待用户明确放行；登记范围与包络同 bound-02，
  估计仍约 400–550 AFP。

### 实跑（live-01，2026-09-18）

用户明确授权后，以 bound-02 执行正式留出实跑（`reports/pareto-holdout-v1/live-01/`）：

- 108 次运行全部完成；397 次真实调用、312.7503 AFP（生产 171.3863、评审 141.364）、
  零重试、墙钟约 52.6 分钟；95 次交付未确认、11 次扣留、2 次失败（失败计入分母）。
- 运行内评审给出 quality_status pending 65、fail 43；官方质量门槛仍需 MoA 输出评审，
  `quality_gate_pending=true`，三个臂的 AFP per accepted task 暂为 null。
- 分析产物 `reports/pareto-holdout-v1/live-01-analysis.json` 已归档；确认性结论待
  输出评审完成后重新分析。

## 运行与真人证据导入

默认入口只冻结，绝不调用模型；执行必须使用该文件且不得覆盖范围。

```bash
uv run python experiments/run_bound_quality_study.py \
  --task-ids rules-02 --repeats 1 --output-dir /tmp/quality-preflight-new
uv run python experiments/run_bound_quality_study.py --live \
  --frozen /tmp/quality-preflight-new/frozen.json --output-dir /tmp/quality-live-new
```

付费留出运行要求先提供真实材料审查数组与用途确认对象；缺失时在创建客户端前拒绝执行。
材料审查需要任务与参考哈希、非构造者的真实身份和证据，以及全部材料检查项。
将材料包中实际填写的 `review` 连同其 `task_id` 整理成数组供 `--material-reviews` 使用。
用途确认对象使用冻结模板的 policy 和 task bindings，不能复制虚构人员或测试证据。

```bash
uv run python experiments/run_bound_quality_study.py --live \
  --frozen /path/to/frozen.json --output-dir /path/to/new-run \
  --material-reviews /path/to/real-material-reviews.json \
  --purpose-review /path/to/real-purpose-review.json
uv run python experiments/analyze_bound_quality_study.py \
  --study-dir data/quality-study-v1 --frozen /path/to/new-run/frozen.json \
  --results /path/to/new-run/evaluated-results.json --output /path/to/new-analysis.json \
  --human-reviews /path/to/real-output-reviews.json \
  --purpose-review /path/to/real-purpose-review.json
```

所有输出目录和分析文件必须是新路径。模型、费率、核心实现、研究入口、提示、
任务与完整顺序均绑定哈希；任一执行依赖改变必须重新预检。真人意见绑定任务、
输出和验收表，导入后重新计算质量，不能直接编辑报告里的 `quality_status`。
程序验证记录格式及哈希，不认证真人身份；维护者需要核实外部提交记录。

真人材料审查、开发正负例盲审及分歧裁决、用途门槛确认仍未发生。
当前不运行正式留出、不关闭 #52，不把未来最终答案的双审提前写成完成。

用途确认的外部证据应关联实际完成的开发盲审与分歧记录；程序不会认证这些参与事实。
分析入口的 `--blind-output-dir` 可导出实际输出的匿名审查包和单独的私有映射，
协调者保管映射，不发送给初审人员。

执行冻结仍绑定全部实现文件。非真人证据汇总允许运行后分析和汇总脚本有补充修订，
但要求实际调用路径和统计政策与真实验证完全相同；最终冻结会再次记录全部当前文件哈希。
不得将这个证据复用规则用于替换未验证的 planner、提示、选模、调度或计费实现。
