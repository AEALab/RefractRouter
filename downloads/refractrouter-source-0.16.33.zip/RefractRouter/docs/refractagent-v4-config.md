# RefractAgent v4 配置合同

`refractagent-providers-v4` 是自动路由入口的配置版本。它不改变 v1–v3 的历史语义，
也不会自动改写旧配置。完整示例见
[v4 配置示例](../data/schema/refractagent-providers-v4-example.json)。

## 路由目标

v4 使用单一 `objective`，不再接受 `qualityMin` 与 `strategies`：

```json
{
  "qualityMin": 80,
  "primary": "cost",
  "secondary": "latency",
  "dagMode": "auto"
}
```

`qualityMin` 是硬门槛；当前只支持费用优先、时延次优。`dagMode` 可取 `auto`、
`never` 或研究用途的 `force`。DSH 对 v4 只公开 `auto` 模型；v1–v3 继续公开三个历史入口。

## 模型职责与安全

每个模型使用可多选的 `roles`，取值为 `planner`、`worker`、`judge`、`classifier`。
配置至少要有一个 planner、worker 和 judge。部署域必须显式声明，Python 核心负责最终安全、
角色和路由校验；TypeScript 插件只做结构检查和配置透传。

可以在保存或部署前调用 Python 核心的零调用校验入口：

```bash
refractagent validate-config --provider-config ./providers-v4.json
cat ./providers-v4.json | refractagent validate-config --request-stdin
```

成功结果只返回配置版本、Provider/模型数量、职责数量和凭证引用名称，不读取凭证值，
也不发起模型调用。错误配置返回非零退出码和脱敏错误。

`simulated-local` 仍表示云端调用。真实敏感数据只有在其信任策略允许敏感数据、启用审计，
并且显式设置 `acknowledgeExternalTransmission: true` 时才通过 v4 编译。配置快照会同时记录
该确认、求解使用的模拟边际成本以及模型声明的云端价格。v3 的拒绝规则保持不变。

## 显式迁移

迁移命令不会覆盖来源文件，也不会根据模型名称推断职责：

```bash
refractagent migrate-config-v4 \
  --input providers-v3.json \
  --output providers-v4.json \
  --planner-model-id local-planner
```

迁移规则为 `candidate` → `worker`、`judge` → `judge`，指定的 planner 与
`security.classifier.modelId` 分别追加对应职责。输出会经过 Python 核心完整校验。

## 当前开发边界

配置编译、显式迁移、DSH 单一入口合同和安全约束下的零调用 direct-or-DAG 估算已经实现；
估算合同与审计字段见 [v4 两级自动路由选择器](automatic-routing-v4.md)。DSH 设置卡片已提供
路由目标、安全模式、Provider、模型与信任策略的结构化编辑，并显示职责和部署清单的结构预览；
预览不复制 Python 的安全准入或路由判定，高级 JSON 继续支持完整配置的无损往返。

后续已开放有限真实执行及可配置的 DSH 工具接入。当前 v4 `live` 只允许 `synthetic` 数据、
USD／CNY 模型池，并要求规划修复、动态再拆和节点回退为零；预检摘要与模型目录绑定后才能派发。
真实入口目前通过请求结构规则决定直答或进入规划，完整的两级费用／时延选择器尚未接入。
本地拆分前判别已按[独立合同](automatic-local-decisions.md)接入：设置页可选择规则或
“规则＋本地 Laya”，并检查、加载和预热固定 revision；后者的专项质量验收未达标，
继续保持实验标识。

Issue #116 已关闭，后续应按 #113 及其依赖明确跟踪执行接入、运行期安全合同覆盖、预测与
实际费用对照及独立研究验收；不能把配置、模拟或有限真实入口通过解释为完整自动选路已交付。
