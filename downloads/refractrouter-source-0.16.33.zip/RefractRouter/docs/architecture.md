# 项目架构与职责边界

## 仓库与产品定位

RefractRouter 是面向小型开发团队的独立模型路由服务，目标顺序是可接受质量、
较低的全部模型费用、较短的响应与等待时间。Static、Stage、Task、Escalation
使用宿主中立的 Python 策略与账本，标准模型 API 由协议适配层提供。

Agent 的工具执行、审批、技能、提示组织、上下文压缩、子 Agent 和任务生命周期由宿主负责。
DSH 插件只提供宿主适配、设置与展示，不是核心或唯一入口。
历史 DAG 任务分解、组合执行与内部工具循环属于独立实验路径，不进入标准模型请求。

新增模型 HTTP 服务与旧自定义任务服务的区别，以及实际兼容范围，见
[独立模型路由决策](independent-model-router.md)。接口通过不代表已经证明路由节省或质量保证。

当前保持同仓库便于核心、调用协议和插件在同一次变更中验证。目录边界如下：

| 层次 | 语言与目录 | 职责 |
|---|---|---|
| Router 核心与任务运行时 | Python：`src/refractrouter/` | DAG、节点模型分配、执行与上下文传递、策略、模型适配器、预算记账、成本与时延统计、评分与评估 |
| 实验与证据 | `experiments/`、`data/`、`reports/` | 组织对照实验、冻结任务与模型清单、保存可追溯证据 |
| DSH 插件 | TypeScript：`validation/dsh/plugin/src/` | 工具入口、配置与类型、宿主服务、进程与凭证边界、结果展示 |
| DSH 调用与验证入口 | Python：`validation/dsh/` 下的 runner | 连接插件与核心、组织验证、保存产物和证据 |
| DSH 契约测试 | TypeScript：`validation/dsh/plugin/tests/` | 宿主模拟、入口与包兼容性、零调用预检、预算与端点检查、进程控制 |

保留 `validation/dsh/` 路径以沿用现有安装、脚本与 CI 引用；该目录承载 DSH 验证和
产品入口探索，其名称不代表核心必须经由 DSH 才能使用。

## 规划路由的独立执行入口

新增 RefractAgent 规划路由，与原 DAG 自动路由并存。
DSH 拥有原生 Agent 循环、工具、审批、会话与上下文压缩；Python 通过持久工作进程
拥有 Static、Stage、Task、Composite、Advisor、Escalation 的策略状态、准入与账本。
TypeScript 只传递原生请求、执行核心签发的模型调用及展示轨迹。
此路径不创建 DAG，也不复用 Python 内部工具循环。完整合同见
[规划路由](trajectory-routing-strategies.md)。
Task v3 的模型池、共同 Judge 合同、本地 Laya-MLX 及媒体边界见
[Task 多模型路由、本地 Judge 与媒体接入](task-local-judge-media.md)。

## 独立模型调用边界

```mermaid
flowchart LR
    Agent[接入方 Agent：工具、审批、上下文] --> API[标准模型 HTTP 协议]
    DSH[DSH 原生 Agent] --> Plugin[DSH 宿主适配]
    API --> Policy[Python 策略、准入与账本]
    Plugin --> Policy
    Policy --> Models[实际模型与 Judge]
```

模型返回的工具调用原样交由接入方执行。标准接口当前的文本/function 范围见独立接口文档。

## 历史 DAG 研究调用边界

以下为保留的 DAG 与实验入口，不能当作标准模型接口的执行路径。

```mermaid
flowchart LR
    DSH[DSH 宿主] --> Plugin[DSH 插件：工具与宿主适配]
    Plugin --> Runner[本地 Python runner]
    Plugin --> HTTP[RefractRouter HTTP 服务]
    CLI[本地命令与实验入口] --> Core[RefractRouter 核心与任务运行时]
    Runner --> Core
    HTTP --> Core
    Core --> Models[已选模型与独立评审模型]
    Core --> Results[执行结果与评估证据]
    Results --> Plugin
```

冻结基准由应用提供固定 DAG，Python 通过 DeepAgents/LangGraph 执行。
文本任务运行时使用 `text-task-plan-v2` 请求模型生成最多 8 个节点的 DAG，
校验依赖字段、输出契约、能力容量与验收覆盖，并生成结构诊断。规划器必须说明拆分理由，
允许单节点及独立分支；详见 [拆分机制](dag-decomposition.md)。由 Python 校验后按依赖就绪顺序
执行文本节点，默认串行，可配置有界并发、provider 并发上限及启动间隔。
该路径使用独立的 Python 任务执行循环，调度预测与执行共享策略，预算预留原子化。两种路径的模型分配和评估均由
Python 负责。文本任务的质量 profile 是选模预测依据，实际质量由最终独立评估检验。

DSH 提供会话、工具调度、进程生命周期、沙箱和凭证服务。插件检查宿主输入及部署上限，
可通过原生子进程启动固定 Python runner，也可把同一请求发送到用户明确配置的 Router URL，
并转换返回的证据。HTTP v1 保留同步兼容，HTTP v2 增加持久任务、成员/项目访问、幂等与
事件续读；两个协议都只开放预检和模拟。非回环地址要求 HTTPS，服务端部署上限不能被
客户端放大。DSH 外层助手的模型配置
与 Router 对 DAG 节点的选模分别管理；采用 DSH LLM 桥时，桥按核心指定的模型执行请求。

核心业务接口不得绑定 DSH 类型或要求 DSH 会话。DSH 相关协议适配应留在集成边界，
插件不得重复实现路由、评分、预算记账或 Go/No-go 判定。TypeScript 部署预算上限用于
限制宿主可请求的范围，Python 负责逐次模型调用的预算账本。

历史实验的 AFP 清单保留 `ark-plan` 与精确的 `/api/plan/v3` 端点。插件仅在启用付费执行并提供
生产、评审两项显式预算后解析凭证。通用 DSH LLM 桥传递请求与遥测，不决定节点模型
或评估质量。

## 用户配置的 provider 与模型

DSH 插件的普通设置保存 `dshModelPool`，只记录用户从宿主目录选择的 `(provider, model)`、
部署属性与高级覆盖。插件在每次运行前解析 `dshCatalogSnapshot`，检查路线仍存在且容量元数据
完整；Python 再将目录事实、冻结公开档案和用户覆盖编译为 v4 配置。冻结价格档案保存完整的
条件价格计划，并为现有标量预算合同选择保守阶梯；订阅 provider 的执行资源与模型原厂参考价
保持不同语义。TypeScript 不分配模型职责，
也不计算价格、质量或时延。旧 `providerConfig` 继续作为 CLI、历史配置和非 DSH 入口。

应用的 `providerConfig` 由 Python 编译为模型清单与 `configured` 路由 profile，
支持一个或多个生产候选及一个评审模型。用户声明的质量和时延预测使用零观测样本，
不能替代经验数据；历史研究运行时仍要求实测 profile，不能直接借用应用配置绕过该条件。
产品开发测试可通过显式 `allowSharedJudge` 让一个模型兼任执行与评审；默认仍保持职责隔离，
共享时证据必须标记非独立评审。该能力只放宽产品配置形态，不降低研究协议的独立评审门槛。

Ark Agent Plan 是可选 provider 类型或显式预设。其他 provider 可由 Python 通过
Chat Completions / Responses 接口调用，或通过 DSH 原生模型服务适配。目标 provider 和模型均由
核心选定；插件只建立允许调用的宿主模型清单、传递请求并检查调用边界。
直接 HTTP 凭证通过专用子进程环境传递，宿主原生凭证保留在 DSH 中。
不同 provider 的同名模型由 provider 与模型 ID 共同标识，禁止回调 RefractAgent 自身。

价格必须使用用户声明的共同单位，Python 校验并记账，不自动换算货币或 AFP。
应用模型类型继承基础模型类型以增加 HTTP 认证和 token 参数选项，历史模型序列化保持原样。
Responses 的推理和正文共用输出包络，候选容量检查、预算预留与发送参数使用同一个上限；
历史协议仍保持 8192。解析器将正文、结束状态和用量转换为核心结果，不把推理条目当作答案。
应用候选以配置 ID 标识完整执行配置，同一 provider 的物理模型可以声明多个 reasoning effort。
Python 根据节点类型、难度、风险和输入包络匹配该候选的预测，再沿用现有 DAG 组合求解器。
不把 effort 变成跨模型通用质量分，也不要求规划器预先选择档位。默认预测与不重叠的分层
预测由用户提供；每次 profile 绑定有效请求设置与价格，不能跨档位直接复用。
预测成本可以使用包含推理 token 的 `outputTokens`，实际派发仍按完整输出上限预留；
预测可行不保证硬预留一定充足。执行与评审记录保留所发送的档位，DSH 只传配置和展示结果。
完整配置见 [provider 与模型说明](provider-configuration.md)。

## 当前交付边界

- RefractAgent 0.9.0 提供可安装的 Python 应用命令、随包资源、兼容 HTTP v1 和持久任务
  HTTP v2。v2 使用静态成员 token、项目 ACL 和 SQLite WAL，支持幂等、取消、事件续读与
  重启恢复；仍不开放 DSH 宿主工具回调或 v4 付费执行。参见
  [HTTP 服务](router-http-service.md)和[团队服务](team-router-service.md)。
- DSH 插件 0.22.0 接入 HTTP v2：宿主侧解析 Router 凭证并发现授权项目，提交后以任务 ID 和
  事件序号恢复显示；提交后的故障不会自动回退本地执行或创建第二个任务。
- 历史 RefractAgent 0.3.0 首次提供可安装的 Python 应用命令和随包资源。
  DSH 插件 0.11.0 的 `refractagent` provider 注册省成本、均衡、质量优先三个模型接口，
  通过原生子进程服务调用已安装核心，传入会话与部署上限；策略及记账仍完全由 Python 决定。
  该入口自核心 0.6.0／插件 0.17.0 起支持节点内原生工具循环：Python 负责逐轮预留、
  模型续调及 DAG 状态；TypeScript 使用真实发起 Agent 调用宿主 `tools.execute`，
  保留权限、审批及工具轨迹。参见[工具边界](native-tool-execution.md)；安装方式见
  [本机安装说明](refractagent-local-quickstart.md)。
- `refractrouter_validate` 调用基准验证入口；`refractrouter_task` 调用文本任务入口。
  这两个历史工具仍依赖匹配的 Python 源码环境和配置数据。
- RefractAgent 模型入口可脱离源码目录运行；默认仍为本机执行，也可连接独立 Router 服务。
  DSH 保持为一种宿主接入方式。

## 实现语言与构建分发

显式启用的 v0.4 [证据状态实验](evidence-state-execution-modes.md) 将不可变来源归属、
整任务与 DAG 执行、对照分组和费用记账保留在 Python。DSH 仅传递配置并展示证据。

实现语言边界为 Python + TypeScript。Markdown、JSON 和 YAML 用于文档与数据；
TypeScript 编译生成的 JavaScript 是运行产物，不新增手写 JavaScript 实现。

插件 `src/index.ts` 编译到 `dist/index.js`，`main` 和 `exports` 指向生成入口，
`dist/*.d.ts` 提供类型声明。源码和测试编译配置均启用 `strict`，遇到错误时拒绝生成。
`contracts.ts` 的结构化宿主接口描述本包使用的 DSH `0.1.1-rc.2` 服务；通过类型模拟
和隔离 profile 启动验证兼容性。

`package-lock.json` 锁定 TypeScript 和 Node 类型开发依赖。构建命令为：

```bash
npm ci --prefix validation/dsh/plugin
npm run --prefix validation/dsh/plugin build
```

DSH 使用 pnpm `10.15.0` 安装 profile；npm 管理插件开发工具链。
私有插件包包含生成的 `dist/`、`package.json`、`cordis.patch.yml`、`README.md` 和
`CHANGELOG.md`。测试单独编译到忽略的 `.test-dist/` 并针对 `dist/` 执行，两个生成
目录都不提交。`npm pack` 通过 `prepack` 构建；安装源码目录前需要显式构建。
插件包没有运行时 npm 依赖，也不在安装时编译。RefractAgent 模型接口需要安装匹配的
Python 核心包；历史验证工具仍需要匹配的源码环境。

## 架构评审规则

新增实现语言或跨层复制业务决策前，应在架构 Issue 或 ADR 中记录提案，并在合并前取得
维护者批准。提案应说明职责归属、现有语言无法满足的需求、替代方案、依赖和分发成本、
数据契约、测试覆盖、迁移或回滚策略。如果提议重复实现，应明确权威实现及防止行为偏差
的方式。既有职责边界内的常规修改无需另行架构批准。

## 验证

CI 安装锁定的 Python 和 TypeScript 依赖，检查类型、构建插件并运行 `uv run pytest`，
其中包含编译后的 TypeScript 契约测试。兼容矩阵在 Node `22.19.0` 和最新 Node 22 上
启动 DSH `0.1.1-rc.2`，覆盖安装、配置覆盖、卸载、重装及源码和打包分发路径。
这些检查不调用模型。`reports/` 下已完成实验的原始证据继续保留。
